/*
 Navicat Premium Data Transfer

 Source Server         : jbz
 Source Server Type    : MySQL
 Source Server Version : 50539
 Source Host           : localhost:3306
 Source Schema         : ssm

 Target Server Type    : MySQL
 Target Server Version : 50539
 File Encoding         : 65001

 Date: 10/01/2023 15:17:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for member
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nickName` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `phoneNum` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '成员表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES (1, '张三', '小三', '13888888881', 'zhangsan@qq.com');
INSERT INTO `member` VALUES (2, '李四', '小四', '13512588907', 'lisi12@qq.com');

-- ----------------------------
-- Table structure for order_traveller
-- ----------------------------
DROP TABLE IF EXISTS `order_traveller`;
CREATE TABLE `order_traveller`  (
  `orderId` int(11) NOT NULL,
  `travellerId` int(11) NULL DEFAULT NULL,
  INDEX `fk_ot_o`(`orderId`) USING BTREE,
  INDEX `fk_ot_t`(`travellerId`) USING BTREE,
  CONSTRAINT `order_traveller_ibfk_2` FOREIGN KEY (`travellerId`) REFERENCES `traveller` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `order_traveller_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单和游客中间表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of order_traveller
-- ----------------------------
INSERT INTO `order_traveller` VALUES (2, 3);
INSERT INTO `order_traveller` VALUES (2, 4);
INSERT INTO `order_traveller` VALUES (6, 1);
INSERT INTO `order_traveller` VALUES (6, 2);
INSERT INTO `order_traveller` VALUES (6, 3);
INSERT INTO `order_traveller` VALUES (6, 4);
INSERT INTO `order_traveller` VALUES (8, 2);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` int(32) NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `orderNum` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '订单编号',
  `orderTime` datetime NULL DEFAULT NULL COMMENT '订单时间',
  `peopleCount` int(11) NULL DEFAULT NULL COMMENT '人数',
  `orderDesc` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '订单描述',
  `payType` int(11) NULL DEFAULT NULL COMMENT '0代表未支付 1代表微信支付 2代表支付宝 3代表现金',
  `orderStatus` int(11) NULL DEFAULT NULL COMMENT '0代表已取消 1代表已完成  2代表未支付',
  `productId` int(11) NULL DEFAULT NULL COMMENT '产品id',
  `memberId` int(11) NULL DEFAULT NULL COMMENT '成员id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_o_p`(`productId`) USING BTREE,
  INDEX `fk_o_m`(`memberId`) USING BTREE,
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`memberId`) REFERENCES `member` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (2, 'TT-2020-0415-003', '2020-04-15 11:15:17', 2, '无', 2, 1, 1, 1);
INSERT INTO `orders` VALUES (6, 'TT-2022-0108-002', '2023-01-08 21:01:08', 4, '无', 1, 1, 5, 1);
INSERT INTO `orders` VALUES (8, 'TT-2022-0108-004', '2023-01-08 21:01:39', 1, '无', 2, 1, 19, 1);

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23537 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES (107, '角色权限', '/role/queryAllRole');
INSERT INTO `permission` VALUES (1943, '资源权限', '/permission/queryAllPermission');
INSERT INTO `permission` VALUES (23527, '用户权限', '/user/findAllUser');
INSERT INTO `permission` VALUES (23528, '访客权限', '/personal/*');
INSERT INTO `permission` VALUES (23529, '超级权限', '/*');
INSERT INTO `permission` VALUES (23530, '订单权限', '/orders/queryAllOrders');
INSERT INTO `permission` VALUES (23531, '商品权限', '/product/queryProductList');
INSERT INTO `permission` VALUES (23532, '旅客权限', '/traveller/queryAllTraveller');
INSERT INTO `permission` VALUES (23535, '成员权限', '/member/queryAllMember');
INSERT INTO `permission` VALUES (23536, '日志权限', '/sysLog/findAll');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productNum` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `productName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cityName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `departureTime` date NULL DEFAULT NULL,
  `productPrice` double(11, 0) NULL DEFAULT NULL,
  `productDesc` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `productStatus` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '产品表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, '001', '上海一日游', '上海', '2023-01-07', 3800, '沿着外滩一直走，静静的享受这华丽的夜景', 1);
INSERT INTO `product` VALUES (2, '002', '北京三日游', '北京', '2022-12-20', 5800, '不到长城非好汉', 1);
INSERT INTO `product` VALUES (3, '005', '深圳七日游', '深圳', '2020-04-06', 18000, '深圳，是个如同仙境般的“世界”', 1);
INSERT INTO `product` VALUES (4, '006', '昭通一日游', '昭通', '2020-05-07', 1200, '地球之肾欢迎您', 1);
INSERT INTO `product` VALUES (5, '008', '无锡国庆游', '无锡', '2022-10-01', 18000, '临太湖识山水,游无锡见真情', 1);
INSERT INTO `product` VALUES (6, '010', '苏州十日游', '苏州', '2021-03-12', 99988, '万般姑苏情，一站苏州通', 1);
INSERT INTO `product` VALUES (7, '011', '南京五一游', '南京', '2022-05-01', 9998, '流淌的秦淮，永远的南京', 1);
INSERT INTO `product` VALUES (8, '009', '南京中秋一日游', '南京', '2022-09-10', 19998, '中秋佳节，与佳人相约秦淮河畔共赏月             ', 1);
INSERT INTO `product` VALUES (9, '012', '盐城丹顶鹤之游', '盐城', '2022-12-20', 9999, '盐城是一个让人打开心扉的地方                     ', 1);
INSERT INTO `product` VALUES (10, '013', '淮安西游之旅', '淮安', '2022-12-20', 300, '万卷生态画，千年运河都       ', 1);
INSERT INTO `product` VALUES (11, '014', '常州一日游', '常州', '2022-12-20', 300, '吴韵常州，常乐之州。', 1);
INSERT INTO `product` VALUES (16, '015', '镇江一日游', '镇江', '2022-12-21', 300, '梦寻第一江山，情醉山水镇江                 ', 1);
INSERT INTO `product` VALUES (17, '016', '泰州一日游', '泰州', '2022-12-21', 300, '梦寻泰州，情醉湖蟹     ', 1);
INSERT INTO `product` VALUES (19, '017', '扬州三日游', '扬州', '2022-12-24', 200, '烟花三月下扬州                    ', 0);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleDesc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 'ADMIN', '系统管理员');
INSERT INTO `role` VALUES (2, 'USER', '用户管理员');
INSERT INTO `role` VALUES (3, 'ORDERS', '订单管理员');
INSERT INTO `role` VALUES (4, 'PERMISSION', '权限管理员');
INSERT INTO `role` VALUES (5, 'PRODUCT', '产品管理员');
INSERT INTO `role` VALUES (6, 'ROOT', '超级管理员');
INSERT INTO `role` VALUES (7, 'GUEST', '访客管理员');

-- ----------------------------
-- Table structure for role_permission
-- ----------------------------
DROP TABLE IF EXISTS `role_permission`;
CREATE TABLE `role_permission`  (
  `permissionId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`permissionId`, `roleId`) USING BTREE,
  INDEX `r_id`(`roleId`) USING BTREE,
  CONSTRAINT `role_permission_ibfk_1` FOREIGN KEY (`permissionId`) REFERENCES `permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role_permission_ibfk_2` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色和权限的中间表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of role_permission
-- ----------------------------
INSERT INTO `role_permission` VALUES (107, 1);
INSERT INTO `role_permission` VALUES (23527, 1);
INSERT INTO `role_permission` VALUES (23536, 1);
INSERT INTO `role_permission` VALUES (23527, 2);
INSERT INTO `role_permission` VALUES (23530, 3);
INSERT INTO `role_permission` VALUES (1943, 4);
INSERT INTO `role_permission` VALUES (23531, 5);
INSERT INTO `role_permission` VALUES (23529, 6);
INSERT INTO `role_permission` VALUES (23528, 7);

-- ----------------------------
-- Table structure for syslog
-- ----------------------------
DROP TABLE IF EXISTS `syslog`;
CREATE TABLE `syslog`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `visitTime` datetime NULL DEFAULT NULL COMMENT '访问时间',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '操作者用户名',
  `ip` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问ip',
  `url` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问资源url',
  `executionTime` int(11) NULL DEFAULT NULL COMMENT '执行时长',
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问方法',
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 769 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统日志表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of syslog
-- ----------------------------
INSERT INTO `syslog` VALUES (321, '2023-01-08 12:18:53', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (322, '2023-01-08 12:19:28', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (323, '2023-01-08 12:28:23', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 434, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (324, '2023-01-08 12:28:27', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (325, '2023-01-08 12:28:32', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (326, '2023-01-08 12:28:34', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (327, '2023-01-08 12:28:41', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (328, '2023-01-08 12:28:55', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (329, '2023-01-08 12:30:12', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 356, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (330, '2023-01-08 12:30:15', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (331, '2023-01-08 12:30:18', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (332, '2023-01-08 12:30:26', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 13, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (333, '2023-01-08 12:30:36', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 9, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (334, '2023-01-08 12:32:06', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 24, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (335, '2023-01-08 12:32:10', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 5, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (336, '2023-01-08 12:32:18', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (337, '2023-01-08 12:33:16', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 602, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (338, '2023-01-08 12:33:20', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (339, '2023-01-08 12:33:23', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (340, '2023-01-08 12:33:28', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (341, '2023-01-08 12:33:31', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (342, '2023-01-08 12:34:21', 'JBZ0805', '192.168.0.106', '/personal/login', 357, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (343, '2023-01-08 12:35:26', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 4435, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (344, '2023-01-08 12:35:48', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 52901, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (345, '2023-01-08 12:36:41', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (346, '2023-01-08 12:38:05', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 367, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (347, '2023-01-08 12:38:08', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (348, '2023-01-08 12:38:15', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (349, '2023-01-08 12:40:54', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 361, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (350, '2023-01-08 12:42:49', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 17, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (351, '2023-01-08 12:42:52', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (352, '2023-01-08 12:48:06', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 761, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (353, '2023-01-08 12:48:10', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (354, '2023-01-08 12:48:19', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (355, '2023-01-08 12:59:40', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 635, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (356, '2023-01-08 12:59:43', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (357, '2023-01-08 13:01:37', 'JBZ0805', '192.168.0.106', '/personal/login', 299, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (358, '2023-01-08 13:01:48', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 68, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (359, '2023-01-08 13:01:50', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (360, '2023-01-08 13:04:33', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 18, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (361, '2023-01-08 13:04:36', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (362, '2023-01-08 13:04:59', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 442, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (363, '2023-01-08 13:05:01', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (364, '2023-01-08 13:05:13', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (365, '2023-01-08 13:06:25', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 21, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (366, '2023-01-08 13:06:30', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (367, '2023-01-08 13:06:34', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 4, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (368, '2023-01-08 13:12:18', 'JBZ0805', '192.168.0.106', '/personal/login', 574, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (369, '2023-01-08 13:12:23', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 69, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (370, '2023-01-08 13:12:34', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 13, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (371, '2023-01-08 13:12:36', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (372, '2023-01-08 13:23:10', 'JBZ0805', '192.168.0.106', '/personal/login', 525, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (373, '2023-01-08 13:23:38', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 66, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (374, '2023-01-08 13:23:53', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (375, '2023-01-08 13:23:55', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (376, '2023-01-08 13:25:19', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 19, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (377, '2023-01-08 13:25:43', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 6, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (378, '2023-01-08 13:25:46', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (379, '2023-01-08 13:25:52', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (380, '2023-01-08 13:27:07', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 6, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (381, '2023-01-08 13:27:09', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (382, '2023-01-08 13:27:14', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (383, '2023-01-08 13:27:17', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (384, '2023-01-08 13:27:21', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (385, '2023-01-08 13:28:00', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 6, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (386, '2023-01-08 13:28:02', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (387, '2023-01-08 13:28:05', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (388, '2023-01-08 13:28:07', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (389, '2023-01-08 13:28:10', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (390, '2023-01-08 13:28:12', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (391, '2023-01-08 13:28:14', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (392, '2023-01-08 13:28:22', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (393, '2023-01-08 13:32:05', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 7, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (394, '2023-01-08 13:32:07', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (395, '2023-01-08 13:32:11', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (396, '2023-01-08 13:32:14', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (397, '2023-01-08 13:32:17', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (398, '2023-01-08 13:32:23', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (399, '2023-01-08 13:32:26', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 5, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (400, '2023-01-08 13:32:42', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (401, '2023-01-08 13:32:47', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 3, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (402, '2023-01-08 13:32:48', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (403, '2023-01-08 13:33:35', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (404, '2023-01-08 13:35:09', 'JBZ0805', '192.168.0.106', '/personal/login', 508, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (405, '2023-01-08 13:35:21', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 73, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (406, '2023-01-08 13:35:25', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (407, '2023-01-08 13:39:36', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 584, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (408, '2023-01-08 13:39:39', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (409, '2023-01-08 13:39:44', 'JBZ0805', '192.168.0.106', '/personal/exit', 11, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (410, '2023-01-08 13:39:47', 'JBZ0805', '192.168.0.106', '/personal/login', 3, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (411, '2023-01-08 13:39:51', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 4, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (412, '2023-01-08 13:39:52', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 1, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (413, '2023-01-08 13:41:10', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 24, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (414, '2023-01-08 13:41:11', 'JBZ0805', '192.168.0.106', '/user/add', 2, '[类名]com.jbz.controller.UserController[方法名]add', 'SUCCESS');
INSERT INTO `syslog` VALUES (415, '2023-01-08 13:43:05', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 725, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (416, '2023-01-08 13:43:07', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 13, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (417, '2023-01-08 13:43:14', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 17, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (418, '2023-01-08 13:43:16', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (419, '2023-01-08 13:43:19', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (420, '2023-01-08 13:43:58', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 576, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (421, '2023-01-08 13:44:05', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (422, '2023-01-08 13:44:09', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 4, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (423, '2023-01-08 13:44:57', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 500, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (424, '2023-01-08 13:44:59', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (425, '2023-01-08 13:45:02', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 6, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (426, '2023-01-08 13:45:03', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (427, '2023-01-08 13:45:07', 'JBZ0805', '192.168.0.106', '/traveller/save', 3, '[类名]com.jbz.controller.TravellerController[方法名]updateTraveller', 'SUCCESS');
INSERT INTO `syslog` VALUES (428, '2023-01-08 13:45:07', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 10, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (429, '2023-01-08 13:45:10', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (430, '2023-01-08 13:45:14', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (431, '2023-01-08 13:45:20', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (432, '2023-01-08 13:45:25', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (433, '2023-01-08 13:46:46', 'JBZ0805', '192.168.0.106', '/traveller/queryAllTraveller', 497, '[类名]com.jbz.controller.TravellerController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (434, '2023-01-08 13:46:49', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (435, '2023-01-08 13:46:51', 'JBZ0805', '192.168.0.106', '/traveller/queryTravellerById', 2, '[类名]com.jbz.controller.TravellerController[方法名]queryTravellerById', 'SUCCESS');
INSERT INTO `syslog` VALUES (436, '2023-01-09 16:42:23', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 552, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (437, '2023-01-09 16:42:43', 'JBZ0805', '192.168.0.106', '/personal/exit', 14, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (438, '2023-01-09 16:43:20', 'tom0112', '192.168.0.106', '/personal/login', 4, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (439, '2023-01-09 16:43:28', 'tom0112', '192.168.0.106', '/user/findAllUser', 12, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (440, '2023-01-09 16:43:43', 'tom0112', '192.168.0.106', '/user/findAllUser', 8, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (441, '2023-01-09 17:29:35', 'JBZ0805', '192.168.0.106', '/personal/login', 553, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (442, '2023-01-09 17:29:44', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 105, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (443, '2023-01-09 17:46:20', 'JBZ0805', '192.168.0.106', '/permission/queryAllPermission', 84, '[类名]com.jbz.controller.PermissionController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (444, '2023-01-09 17:46:42', 'JBZ0805', '192.168.0.106', '/permission/queryAllPermission', 4, '[类名]com.jbz.controller.PermissionController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (445, '2023-01-09 17:47:01', 'JBZ0805', '192.168.0.106', '/permission/queryAllPermission', 226, '[类名]com.jbz.controller.PermissionController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (446, '2023-01-09 17:48:02', 'JBZ0805', '192.168.0.106', '/permission/queryAllPermission', 239, '[类名]com.jbz.controller.PermissionController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (447, '2023-01-09 17:48:37', 'JBZ0805', '192.168.0.106', '/permission/queryAllPermission', 265, '[类名]com.jbz.controller.PermissionController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (448, '2023-01-09 17:49:09', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 16, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (449, '2023-01-09 18:20:30', 'JBZ0805', '192.168.0.106', '/personal/login', 646, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (450, '2023-01-09 18:20:36', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 89, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (451, '2023-01-09 18:20:38', 'JBZ0805', '192.168.0.106', '/user/add', 4, '[类名]com.jbz.controller.UserController[方法名]add', 'SUCCESS');
INSERT INTO `syslog` VALUES (452, '2023-01-09 18:20:41', 'JBZ0805', '192.168.0.106', '/personal/exit', 0, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (453, '2023-01-09 18:21:08', 'tom0112', '192.168.0.106', '/personal/login', 3, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (454, '2023-01-09 18:21:34', 'tom0112', '192.168.0.106', '/personal/queryPersonalUserById', 2, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (455, '2023-01-09 18:22:22', 'tom0112', '192.168.0.106', '/product/queryProductList', 13, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (456, '2023-01-09 18:22:57', 'tom0112', '192.168.0.106', '/product/queryProductList', 8, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (457, '2023-01-09 18:22:59', 'tom0112', '192.168.0.106', '/product/queryProductList', 4, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (458, '2023-01-09 18:23:05', 'tom0112', '192.168.0.106', '/product/queryProductList', 11, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (459, '2023-01-09 18:23:08', 'tom0112', '192.168.0.106', '/product/queryProductList', 3, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (460, '2023-01-09 18:23:16', 'tom0112', '192.168.0.106', '/orders/queryAllOrders', 18, '[类名]com.jbz.controller.OrdersController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (461, '2023-01-09 18:23:28', 'tom0112', '192.168.0.106', '/personal/queryPersonalUserById', 2, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (462, '2023-01-09 18:23:34', 'tom0112', '192.168.0.106', '/personal/save', 3, '[类名]com.jbz.controller.PersonalController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (463, '2023-01-09 18:23:44', 'tom0112', '192.168.0.106', '/personal/queryPersonalUserById', 1, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (464, '2023-01-09 18:23:49', 'tom0112', '192.168.0.106', '/personal/save', 1, '[类名]com.jbz.controller.PersonalController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (465, '2023-01-09 18:23:51', 'tom011', '192.168.0.106', '/personal/queryPersonalUserById', 2, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (466, '2023-01-09 18:23:55', 'tom011', '192.168.0.106', '/personal/save', 8, '[类名]com.jbz.controller.PersonalController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (467, '2023-01-09 18:24:07', 'tom0112', '192.168.0.106', '/personal/exit', 1, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (468, '2023-01-09 18:24:10', 'JBZ0805', '192.168.0.106', '/personal/login', 2, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (469, '2023-01-09 18:24:12', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 24, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (470, '2023-01-09 18:24:14', 'JBZ0805', '192.168.0.106', '/user/add', 2, '[类名]com.jbz.controller.UserController[方法名]add', 'SUCCESS');
INSERT INTO `syslog` VALUES (471, '2023-01-09 18:24:22', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 6, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (472, '2023-01-09 18:24:30', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 2, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (473, '2023-01-09 18:24:37', 'JBZ0805', '192.168.0.106', '/user/edit', 30, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'EXCEPTION');
INSERT INTO `syslog` VALUES (474, '2023-01-09 18:24:42', 'JBZ0805', '192.168.0.106', '/user/edit', 4, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (475, '2023-01-09 18:24:42', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 15, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (476, '2023-01-09 18:24:45', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 3, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (477, '2023-01-09 18:24:50', 'JBZ0805', '192.168.0.106', '/user/edit', 5, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (478, '2023-01-09 18:24:50', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 10, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (479, '2023-01-09 19:08:10', 'JBZ0805', '192.168.0.106', '/personal/login', 550, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (480, '2023-01-09 19:08:15', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 77, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (481, '2023-01-09 19:08:30', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 17, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (482, '2023-01-09 19:08:32', 'JBZ0805', '192.168.0.106', '/user/add', 5, '[类名]com.jbz.controller.UserController[方法名]add', 'SUCCESS');
INSERT INTO `syslog` VALUES (483, '2023-01-09 19:08:35', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 8, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (484, '2023-01-09 19:08:38', 'JBZ0805', '192.168.0.106', '/user/edit', 9, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (485, '2023-01-09 19:08:38', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 15, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (486, '2023-01-09 19:08:41', 'JBZ0805', '192.168.0.106', '/personal/exit', 3, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (487, '2023-01-09 19:08:59', 'tom0112', '192.168.0.106', '/personal/login', 1, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (488, '2023-01-09 19:09:03', 'tom0112', '192.168.0.106', '/sysLog/findAll', 0, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (489, '2023-01-09 19:09:03', 'tom0112', '192.168.0.106', '/sysLog/findAll', 8, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (490, '2023-01-09 19:11:21', 'tom0112', '192.168.0.106', '/personal/login', 0, '[类名]com.jbz.controller.PersonalController[方法名]login', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (491, '2023-01-09 19:11:21', 'tom0112', '192.168.0.106', '/personal/login', 521, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (492, '2023-01-09 19:11:27', 'tom0112', '192.168.0.106', '/personal/login', 0, '[类名]com.jbz.controller.PersonalController[方法名]login', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (493, '2023-01-09 19:11:27', 'tom0112', '192.168.0.106', '/personal/login', 13, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (494, '2023-01-09 19:12:40', 'tom0112', '192.168.0.106', '/personal/login', 0, '[类名]com.jbz.controller.PersonalController[方法名]login', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (495, '2023-01-09 19:12:40', 'tom0112', '192.168.0.106', '/personal/login', 19, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (496, '2023-01-09 19:18:55', 'tom0112', '192.168.0.106', '/personal/login', 0, '[类名]com.jbz.controller.PersonalController[方法名]login', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (497, '2023-01-09 19:19:30', 'tom0112', '192.168.0.106', '/personal/login', 93853, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (498, '2023-01-09 19:35:12', 'tom0112', '192.168.0.106', '/personal/login', 547, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (499, '2023-01-09 19:35:16', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 65, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (500, '2023-01-09 19:35:19', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 6, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (501, '2023-01-09 19:35:29', 'JBZ0805', '192.168.0.106', '/user/edit', 22, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (502, '2023-01-09 19:35:29', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 13, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (503, '2023-01-09 19:35:31', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 3, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (504, '2023-01-09 19:35:33', 'JBZ0805', '192.168.0.106', '/user/edit', 15, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (505, '2023-01-09 19:35:33', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 15, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (506, '2023-01-09 19:35:35', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 3, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (507, '2023-01-09 19:35:37', 'JBZ0805', '192.168.0.106', '/user/edit', 4, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (508, '2023-01-09 19:35:37', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 12, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (509, '2023-01-09 19:35:39', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 2, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (510, '2023-01-09 19:35:41', 'JBZ0805', '192.168.0.106', '/user/edit', 5, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (511, '2023-01-09 19:35:42', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 17, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (512, '2023-01-09 19:35:43', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 3, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (513, '2023-01-09 19:35:45', 'JBZ0805', '192.168.0.106', '/user/edit', 4, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (514, '2023-01-09 19:35:45', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 11, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (515, '2023-01-09 19:35:48', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 4, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (516, '2023-01-09 19:35:52', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 3, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (517, '2023-01-09 19:36:19', 'JBZ0805', '192.168.0.106', '/personal/exit', 1, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (518, '2023-01-09 19:36:29', 'tom0112', '192.168.0.106', '/personal/login', 1, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (519, '2023-01-09 19:36:32', 'tom0112', '192.168.0.106', '/user/findAllUser', 0, '方法已拦截', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (520, '2023-01-09 19:36:52', 'tom0112', '192.168.0.106', '/sysLog/findAll', 0, '方法已拦截', 'NO PERMISSION');
INSERT INTO `syslog` VALUES (521, '2023-01-09 19:37:22', 'tom0112', '192.168.0.106', '/personal/exit', 0, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (522, '2023-01-09 19:37:29', 'JBZ0805', '192.168.0.106', '/personal/login', 1, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (523, '2023-01-09 19:37:34', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 13, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (524, '2023-01-09 19:37:41', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 5, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (525, '2023-01-09 19:37:44', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (526, '2023-01-09 19:37:59', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (527, '2023-01-09 19:38:05', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 2, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (528, '2023-01-09 19:38:05', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (529, '2023-01-09 19:38:09', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 3, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (530, '2023-01-09 19:38:09', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 2, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (531, '2023-01-09 19:38:12', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 3, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (532, '2023-01-09 19:38:12', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 6, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (533, '2023-01-09 19:38:15', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 2, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (534, '2023-01-09 19:38:15', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 2, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (535, '2023-01-09 19:38:17', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (536, '2023-01-09 19:38:20', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 4, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (537, '2023-01-09 19:38:20', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (538, '2023-01-09 19:38:22', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (539, '2023-01-09 19:38:25', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 3, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (540, '2023-01-09 19:38:25', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (541, '2023-01-09 19:38:27', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (542, '2023-01-09 19:38:31', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 2, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (543, '2023-01-09 19:38:31', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (544, '2023-01-09 19:38:33', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (545, '2023-01-09 19:38:36', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 2, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (546, '2023-01-09 19:38:36', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (547, '2023-01-09 19:38:39', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (548, '2023-01-09 19:38:43', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 3, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (549, '2023-01-09 19:38:43', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 2, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (550, '2023-01-09 19:38:46', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (551, '2023-01-09 19:38:49', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 3, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (552, '2023-01-09 19:38:49', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 2, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (553, '2023-01-09 19:38:52', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (554, '2023-01-09 19:38:54', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 2, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (555, '2023-01-09 19:38:55', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (556, '2023-01-10 08:33:51', 'JBZ0805', '192.168.0.106', '/personal/login', 353, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (557, '2023-01-10 08:35:13', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 74, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (558, '2023-01-10 08:39:33', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 71, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (559, '2023-01-10 08:39:36', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 17, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (560, '2023-01-10 08:39:58', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 3, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (561, '2023-01-10 08:40:12', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 5, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (562, '2023-01-10 08:42:02', 'JBZ0805', '192.168.0.106', '/personal/login', 370, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (563, '2023-01-10 08:42:14', 'JBZ0805', '192.168.0.106', '/orders/queryAllOrders', 60, '[类名]com.jbz.controller.OrdersController[方法名]queryAllOrders', 'SUCCESS');
INSERT INTO `syslog` VALUES (564, '2023-01-10 08:46:56', 'JBZ0805', '192.168.0.106', '/personal/login', 13, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (565, '2023-01-10 08:47:00', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 61, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (566, '2023-01-10 08:48:25', 'JBZ0805', '192.168.0.106', '/personal/login', 21, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (567, '2023-01-10 08:48:28', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 67, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (568, '2023-01-10 08:48:32', 'JBZ0805', '192.168.0.106', '/personal/exit', 1, '[类名]com.jbz.controller.PersonalController[方法名]exitUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (569, '2023-01-10 08:48:39', 'JBZ0805', '192.168.0.106', '/personal/login', 1, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (570, '2023-01-10 08:58:04', 'JBZ0805', '192.168.0.106', '/personal/login', 345, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (571, '2023-01-10 08:58:08', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 57, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (572, '2023-01-10 09:16:23', 'JBZ0805', '192.168.0.106', '/personal/login', 329, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (573, '2023-01-10 09:17:11', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 105, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (574, '2023-01-10 09:17:23', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 5, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (575, '2023-01-10 09:18:27', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 6, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (576, '2023-01-10 09:23:57', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 96, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (577, '2023-01-10 09:25:17', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 6, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (578, '2023-01-10 09:25:33', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 30, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (579, '2023-01-10 09:25:55', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 16, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (580, '2023-01-10 09:25:55', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 15, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (581, '2023-01-10 09:26:05', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (582, '2023-01-10 09:28:00', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 0, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'EXCEPTION');
INSERT INTO `syslog` VALUES (583, '2023-01-10 09:28:01', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 105, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (584, '2023-01-10 09:29:34', 'JBZ0805', '192.168.0.106', '/personal/login', 348, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (585, '2023-01-10 09:29:41', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 65, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (586, '2023-01-10 09:29:48', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 5, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (587, '2023-01-10 09:31:51', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 5, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (588, '2023-01-10 09:38:13', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 63, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (589, '2023-01-10 09:38:24', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 3, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (590, '2023-01-10 09:39:14', 'JBZ0805', '192.168.0.106', '/personal/login', 357, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (591, '2023-01-10 09:39:17', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 54, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (592, '2023-01-10 09:39:30', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 4, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (593, '2023-01-10 09:42:09', 'JBZ0805', '192.168.0.106', '/role/queryAllRole', 34, '[类名]com.jbz.controller.RoleController[方法名]queryAllRole', 'SUCCESS');
INSERT INTO `syslog` VALUES (594, '2023-01-10 09:42:15', 'JBZ0805', '192.168.0.106', '/personal/queryPersonalUserById', 5, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (595, '2023-01-10 09:42:24', 'JBZ0805', '192.168.0.106', '/personal/queryPersonalUserById', 4, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (596, '2023-01-10 09:47:35', 'JBZ0805', '192.168.0.106', '/personal/login', 354, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (597, '2023-01-10 09:47:38', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 0, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'EXCEPTION');
INSERT INTO `syslog` VALUES (598, '2023-01-10 09:47:38', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 82, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (599, '2023-01-10 09:47:47', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 25, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (600, '2023-01-10 09:47:55', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 0, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'EXCEPTION');
INSERT INTO `syslog` VALUES (601, '2023-01-10 09:47:55', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 34, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (602, '2023-01-10 09:49:15', 'JBZ0805', '192.168.0.106', '/product/sysLog\0\0\0\0\0\0\0\0', 150, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (603, '2023-01-10 09:49:40', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 5, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (604, '2023-01-10 09:50:04', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 19, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (605, '2023-01-10 09:50:08', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 15, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (606, '2023-01-10 09:50:13', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (607, '2023-01-10 09:50:49', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 3, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (608, '2023-01-10 09:50:54', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 4, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (609, '2023-01-10 09:51:27', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 16, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (610, '2023-01-10 09:51:36', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 4, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (611, '2023-01-10 09:52:12', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 3, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (736, '2023-01-10 13:07:12', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 13, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (739, '2023-01-10 13:07:18', 'JBZ0805', '192.168.0.106', '/sysLog/delSyslogById', 6, '[类名]com.jbz.controller.SyslogController[方法名]deleteSyslogById', 'SUCCESS');
INSERT INTO `syslog` VALUES (741, '2023-01-10 13:07:25', 'JBZ0805', '192.168.0.106', '/sysLog/delSyslogById', 6, '[类名]com.jbz.controller.SyslogController[方法名]deleteSyslogById', 'SUCCESS');
INSERT INTO `syslog` VALUES (742, '2023-01-10 13:07:25', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 13, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (743, '2023-01-10 13:07:39', 'JBZ0805', '192.168.0.106', '/sysLog/batchDeleteSyslog', 7, '[类名]com.jbz.controller.SyslogController[方法名]batchDeleteSyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (744, '2023-01-10 13:07:39', 'JBZ0805', '192.168.0.106', '/sysLog/findAll', 13, '[类名]com.jbz.controller.SyslogController[方法名]querySyslog', 'SUCCESS');
INSERT INTO `syslog` VALUES (745, '2023-01-10 13:07:57', 'JBZ0805', '192.168.0.106', '/product/queryProductList', 195, '[类名]com.jbz.controller.ProductController[方法名]queryProductList', 'SUCCESS');
INSERT INTO `syslog` VALUES (746, '2023-01-10 13:55:43', 'JBZ0805', '192.168.0.106', '/personal/login', 18, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (747, '2023-01-10 14:22:10', 'JBZ0805', '192.168.0.106', '/personal/login', 23, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (748, '2023-01-10 14:22:15', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 65, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (749, '2023-01-10 14:22:16', 'JBZ0805', '192.168.0.106', '/user/add', 11, '[类名]com.jbz.controller.UserController[方法名]add', 'SUCCESS');
INSERT INTO `syslog` VALUES (750, '2023-01-10 14:22:28', 'JBZ0805', '192.168.0.106', '/user/save', 139, '[类名]com.jbz.controller.UserController[方法名]addUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (751, '2023-01-10 14:22:28', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 27, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (752, '2023-01-10 14:23:09', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 11, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (753, '2023-01-10 14:23:13', 'JBZ0805', '192.168.0.106', '/user/batchDeleteUser', 13, '[类名]com.jbz.controller.UserController[方法名]batchDeleteUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (754, '2023-01-10 14:23:13', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 20, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (755, '2023-01-10 14:25:55', 'JBZ0805', '192.168.0.106', '/personal/queryPersonalUserById', 4, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (756, '2023-01-10 14:25:57', 'JBZ0805', '192.168.0.106', '/personal/save', 18, '[类名]com.jbz.controller.PersonalController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (757, '2023-01-10 14:26:28', 'JBZ0805', '192.168.0.106', '/personal/queryPersonalUserById', 21, '[类名]com.jbz.controller.PersonalController[方法名]queryPersonalUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (758, '2023-01-10 14:26:31', 'JBZ0805', '192.168.0.106', '/personal/save', 92, '[类名]com.jbz.controller.PersonalController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (759, '2023-01-10 14:26:36', 'JBZ0805', '192.168.0.106', '/personal/login', 2, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (760, '2023-01-10 14:27:48', 'JBZ0805', '192.168.0.106', '/personal/login', 426, '[类名]com.jbz.controller.PersonalController[方法名]login', 'SUCCESS');
INSERT INTO `syslog` VALUES (761, '2023-01-10 14:28:03', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 77, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (762, '2023-01-10 14:28:05', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 17, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (763, '2023-01-10 14:28:08', 'JBZ0805', '192.168.0.106', '/user/edit', 112, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (764, '2023-01-10 14:28:08', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 24, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (765, '2023-01-10 14:28:23', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 13, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (766, '2023-01-10 14:28:27', 'JBZ0805', '192.168.0.106', '/user/queryUserById', 12, '[类名]com.jbz.controller.UserController[方法名]queryUserById', 'SUCCESS');
INSERT INTO `syslog` VALUES (767, '2023-01-10 14:28:31', 'JBZ0805', '192.168.0.106', '/user/edit', 108, '[类名]com.jbz.controller.UserController[方法名]updateUser', 'SUCCESS');
INSERT INTO `syslog` VALUES (768, '2023-01-10 14:28:32', 'JBZ0805', '192.168.0.106', '/user/findAllUser', 21, '[类名]com.jbz.controller.UserController[方法名]queryAllUser', 'SUCCESS');

-- ----------------------------
-- Table structure for traveller
-- ----------------------------
DROP TABLE IF EXISTS `traveller`;
CREATE TABLE `traveller`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phoneNum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `credentialsType` int(11) NULL DEFAULT NULL COMMENT '证件类型 0身份证 1护照 2军官证',
  `credentialsNum` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '证件号码',
  `travellerType` int(11) NULL DEFAULT NULL COMMENT '旅客类型(人群) 0 成人 1 儿童',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '游客表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of traveller
-- ----------------------------
INSERT INTO `traveller` VALUES (1, '李四', '女', '14567893214', 1, '123456789009876543', 0);
INSERT INTO `traveller` VALUES (2, '马六', '男', '13478912345', 1, '3209912000609081234', 0);
INSERT INTO `traveller` VALUES (3, '张三', '男', '13512588907', 0, '320234199807670000', 0);
INSERT INTO `traveller` VALUES (4, '坤坤', '女', '13512585612', 0, '320234199807891234', 1);
INSERT INTO `traveller` VALUES (7, '王五', '男', '13512588907', 0, '3209235678923456', 0);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phoneNum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL COMMENT '状态0 未开启 1 开启',
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20622 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'JBZ0805@126.com', 'JBZ0805', '$2a$10$7JmtAReV3QhazZigAk8ij.CwH55LagiDDUYYOl0DxpxgIQvBcxgbi', '13512585612', 1, '2.jpg');
INSERT INTO `user` VALUES (2, 'tom@126.com', 'tom0112', '$2a$10$wPHs24l6QZ5x1hrziAxjhOfi/X7I5A2J0Ap4XNOhypAyyfKvWJrq2', '192456789121', 1, '1.jpg');
INSERT INTO `user` VALUES (3, '1847481123@qq.com', 'wBekvam1', '$2a$10$Ce8LB3jdYDZ2f6HB281zA.4eC7v6ziJdK8MMWg0Yu8ETMg5ToMpIe', '15752250989', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (4, '11948939@qq.com', 'dengdeng', '$2a$10$Ce8LB3jdYDZ2f6HB281zA.4eC7v6ziJdK8MMWg0Yu8ETMg5ToMpIe', '15858650992', 0, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (5, 'jack123@126.com', 'jack123', '$2a$10$i7QFXNog.2TT3pCrekha1uJsw54fcBPqVK1ncWtW6HxaGkiMFCBw.', '13770174399', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (6, 'zhaolong@126.com', 'zhaolong', '$2a$10$Ce8LB3jdYDZ2f6HB281zA.4eC7v6ziJdK8MMWg0Yu8ETMg5ToMpIe', '13888888888', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (6862, '11919@qq.com', 'hz0914', '$2a$10$mEKoiccVd9lmBJh7czLgy.3bIzaGLiUmn1nsQ65mEvSlI7G3K.1J6', '15652985092', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20614, 'zhixing1010@163.com', 'root123', '$2a$10$xmIe31HlXwR5xLKAzzEnju.CDiYZ.qFuCaO832.fFQB0mWYNc/xya', '15752250876', 0, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20615, '1134567@qq.com', 'lisi0098', '$2a$10$7C0Wq7xO5ga2z3F1wuohO.pbA1pXp4ybZF0npDlW9p2GR5qICWDES', '12312312312', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20616, '9876543@qq.com', 'zhangsan', '$2a$10$7VKcn2O8SDm0b.6uUeCGDuOSIVooipyK3wmOQ1I9aqjNIXRCfhQkW', '13512543214', 0, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20617, 'xhy@126.com', 'xhy123', '$2a$10$1bskbkdKy9Mi/9NVxPEj2OlwLLx.20amTaOAc5INkWku3I1SBWgNq', '12312312312', 1, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20618, 'xhj@qq.com', 'xhj0101', '$2a$10$Ft4HJvVjb8sdGCLlTZHQX.c.OHpJjYq/lw7ukYuwhG52BxfgXxBfa', '12312312312', 0, 'user1-128x128.jpg');
INSERT INTO `user` VALUES (20619, '188xhj@qq.com', '188xhj', '$2a$10$2TYJbwTMbFs2L7Vw0kf8culCpNorGV.Ub.X2xLhXL.bonrwunEvra', '12312312312', 1, 'user1-128x128.jpg');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `userId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`userId`, `roleId`) USING BTREE,
  INDEX `roleId`(`roleId`) USING BTREE,
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户角色中间表' ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES (5, 1);
INSERT INTO `user_role` VALUES (6, 1);
INSERT INTO `user_role` VALUES (6862, 1);
INSERT INTO `user_role` VALUES (20615, 1);
INSERT INTO `user_role` VALUES (3, 2);
INSERT INTO `user_role` VALUES (4, 2);
INSERT INTO `user_role` VALUES (5, 2);
INSERT INTO `user_role` VALUES (6, 2);
INSERT INTO `user_role` VALUES (6862, 2);
INSERT INTO `user_role` VALUES (20615, 3);
INSERT INTO `user_role` VALUES (2, 4);
INSERT INTO `user_role` VALUES (20615, 5);
INSERT INTO `user_role` VALUES (1, 6);
INSERT INTO `user_role` VALUES (2, 7);
INSERT INTO `user_role` VALUES (3, 7);
INSERT INTO `user_role` VALUES (4, 7);
INSERT INTO `user_role` VALUES (5, 7);
INSERT INTO `user_role` VALUES (6, 7);
INSERT INTO `user_role` VALUES (20615, 7);
INSERT INTO `user_role` VALUES (20616, 7);
INSERT INTO `user_role` VALUES (20619, 7);

SET FOREIGN_KEY_CHECKS = 1;
